
    <div id="sub-container">
        <div id="mainMenu">
          <i class="fas fa-chevron-left" style="color: #8e9090"></i> MAIN MENU
        </div>
        <hr />
        <div id="sub-container-content">
          <!-- <div class="sidenavContentHeader">Prime Video</div>
          <a href="#"><div class="sidenavContent">All Videos</div></a> -->
        </div>
      </div>
    </div>
    <!--Not Sidenav-->
    <div>

	<div class="main-sec"></div>

<div class="edit-prf-plant-wrap col-lg-12">
      <h2 class="text-center">Hi. How can we help you?</h2>
      <div class="search ser-help-centr">
        <!-- <form action="<?php echo base_url() ?>/help" method="post"></form>
            <input type="text" name="full_search" class="searchTerm" placeholder="Search the help center">
            <button type="submit" class="searchButton">
              <i class="fa fa-search"></i>
          </button>
        </form> -->
        <?php  ?>
      </div>
</div>
