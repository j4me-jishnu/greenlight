

      <div id="sub-container">
        <div id="mainMenu">
          <i class="fas fa-chevron-left" style="color: #8e9090"></i> MAIN MENU
        </div>
        <hr />
        <div id="sub-container-content">
          <!-- <div class="sidenavContentHeader">Prime Video</div>
          <a href="#"><div class="sidenavContent">All Videos</div></a> -->
        </div>
      </div>
    </div>

    <!--Not Sidenav-->
    <div>
<body class="log-bdy">
	<div class="inner-wrapper">
		<div class="container-fluid no-padding">
			<div class="row no-gutters">
				<!-- <div class="col-md-6">
					<div class="main-banner">
						<img src="assets/img/slider.jpg" class="img-fluid full-width main-img" alt="banner">
					</div>
				</div> -->
				<div class="col-md-12">
					<div class="section-2 user-page main-padding login-pad">
						<div class="login-sec">
							<div class="login-box">
								<form  method="post" action="<?php echo base_url(); ?>index.php/register/forgot_pass">
									<h4 class="text-light-black fw-600">Reset Password</h4>
									<div class="row">
										<div class="col-12">
										<!-- 	<p class="text-light-black">Have a corporate username? <a href="#">Click here</a>
											</p> -->
											<div class="form-group">
												<label class="text-light-white fs-14">Email</label>
												<input type="email" name="email" class="form-control form-control-submit" placeholder="Email I'd" required>
											</div>
											
											<div class="form-group">
												<button type="submit" class="btn-second-2 btn-14 btn-submit full-width">Send</button>
											</div>
											
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>



